
import java.sql.Connection;
import java.sql.DriverManager;
public class DBConnection 
{
	static Connection con;
	public static Connection createDBConnection(){
		try
		{
			// load driver
		Class.forName("oracle.jdbc.driver.OracleDriver");
		// get connection
		String url="jdbc:oracle:thin:@localhost:1522:orcl2";
		String user="YOGESH";
		String pass="tiger";
		con=DriverManager.getConnection(url,user,pass);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return con;

}
}
