
import java.util.*;
public class Student
{
	private String name;
    private String id;
	private int age;
	private String grade;
	Student(){};
  Student(String id,String name,int age,String grade){
	  this.name=name;
	  this.id=id;
	  this.age=age;
	  this.grade=grade;
  }
  public String getName(){
	  return name;
  }
  public void setName(String name){
	  this.name=name;
  }
   public String getid(){
	  return id;
  }
  public void setId(String id){
  this.id=id;
  }
   public int getAge(){
	  return age;
  }
  public void setAge(int age){
	  this.age=age;
  }
   public String getGrade(){
	  return grade;
  }
  public void setGrade(String grade){
	  this.grade=grade;
  }
    public String toString()
	{
        return " Student details\n"+"Name = "+name+"\nid = "+id+"\nage = "+age+"\ngrade = "+grade;
	 }


}
