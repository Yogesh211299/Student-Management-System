
import java.util.Scanner;

class Main 
{
	public static void main(String[] args) 
	{
		StudentDaointrf dao=new StudentDaoImpl();
		System.out.println("welcome to Student management System Application");
		Scanner sc=new Scanner(System.in);

		do
		{
			System.out.println("1. Add Student\n"+
				               "2. Show All Student\n"+
				               "3. retrieve Student Based On Id\n"+
				               "4. update Student\n"+
		     	               "5. delete Student\n"+
				               "6. EXIT\n" );
		   System.out.println("Enter Choice: ");	
			int ch=sc.nextInt();
			switch (ch){
			case 1:
				Student std=new Student();
			    System.out.println("Enter ID : ");
				String id=sc.next();
				System.out.println("Enter Name : ");
				            sc.nextLine();
				String name=sc.nextLine();
				System.out.println("Enter Age : ");
                int age=sc.nextInt();
				System.out.println("Enter Grade : ");
				 sc.nextLine();
                String grade=sc.nextLine();
				std.setId(id);
				std.setName(name);
				std.setAge(age);
				std.setGrade(grade);
				dao.addStudent(std);
			    break;
            case 2:
				dao.showAllStudent();
			    break;
			case 3:
				System.out.println("Enter student ID !");
				String sid=sc.next();
				dao.retrieveStudentBasedOnId(sid);
				break;
			case 4:
                System.out.println("Enter student ID !");
			    String id1=sc.next();
				System.out.println("enter your name ");
				      sc.nextLine() ;
				String name1=sc.nextLine();
				dao.updateStudent(id1,name1);
				break;
			case 5:
				System.out.println("enter the id to delete");
			               sc.nextLine();
			    String idd=sc.nextLine();
				dao.deleteStudent(idd);
				break;
		    case 6:
                System.out.println("Thank you for using our appliction !!!");
			    System.exit(0);
				default:
					System.out.println("Enter valid choice !");
			
			}


			}

		while (true);
//		System.out.println("Hello World!");
	}
}
