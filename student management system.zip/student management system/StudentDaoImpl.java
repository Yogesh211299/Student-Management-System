import java.sql.*;
public class StudentDaoImpl implements StudentDaointrf
{
      Connection con;
    @Override	
	public void addStudent(Student std){
		try
		{
		    con=DBConnection.createDBConnection();
	        String query="insert into student values(?,?,?,?)";
	        PreparedStatement pstmt=con.prepareStatement(query);
	         pstmt.setString(1,std.getid());
			 pstmt.setString(2,std.getName());
			 pstmt.setInt(3,std.getAge());
			 pstmt.setString(4,std.getGrade());

			 int cnt=pstmt.executeUpdate();
			 if (cnt!=0)
			 {
				 System.out.println("student add successfully  !!!");
			 }
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Override
	public void showAllStudent(){
		con=DBConnection.createDBConnection();
		String query="select * from student";
		System.out.format("%s\t%s\t%s\t%s\n","ID","NAME","AGE","GRADE");
		System.out.println("--------------------------------------------------");
		try
		{
			Statement stmt=con.createStatement();
		    ResultSet result =stmt.executeQuery(query);
			while(result.next())
			{
				System.out.format("%s\t%s\t%d\t%s\n",
					                 result.getString(1),
					                 result.getString(2),
					                 result.getInt(3),
					                 result.getString(4));
				System.out.println("--------------------------------------------------");

			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	
	}
	
	@Override
	public void retrieveStudentBasedOnId(String id){
	con=DBConnection.createDBConnection();
		String query="select * from student where Sid=\'"+id+"\'";
		System.out.format("%s\t%s\t%s\t%s\n","ID","NAME","AGE","GRADE");
		System.out.println("--------------------------------------------------");
		try
		{
			Statement stmt=con.createStatement();
		    ResultSet result =stmt.executeQuery(query);
			while(result.next())
			{
				System.out.format("%s\t%s\t%d\t%s\n",
					                 result.getString(1),
					                 result.getString(2),
					                 result.getInt(3),
					                 result.getString(4));
				System.out.println("--------------------------------------------------");

			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	
	}
	@Override
	public void updateStudent(String id ,String name){
      con=DBConnection.createDBConnection();
	  String query ="update student set Sname=? where Sid=?";
	  try
	  {
		PreparedStatement pstmt=con.prepareStatement(query);
		pstmt.setString(1,name);
			pstmt.setString(2,id);
			int cnt=pstmt.executeUpdate();
			if (cnt!=0)
			{
				System.out.println("Student details updated successfully");
			}
	  }
	  catch (Exception e)
	  {
		  e.printStackTrace();
	  }
	}

	@Override
	public void deleteStudent(String id){
	con=DBConnection.createDBConnection();
	String query="delete student where sid=?";
	try
	{
	    PreparedStatement pstmt=con.prepareStatement(query);
	pstmt.setString(1,id);
    int cnt=pstmt.executeUpdate();
	if (cnt!=0)
         System.out.println("student deleted successfully");	
	}
	catch (Exception e)
	{
		e.printStackTrace();
	}
	
	}
}
