
public interface StudentDaointrf
{
	//add student 
	public void addStudent(Student std);
	//retrieve all student
	public void showAllStudent();
	//show student based on id
	public void retrieveStudentBasedOnId(String id);
	//update student
	public void updateStudent(String id ,String name);
	//delete student
	public void deleteStudent(String id);
}
