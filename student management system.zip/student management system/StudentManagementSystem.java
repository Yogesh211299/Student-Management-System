import java.util.*;
public class StudentManagementSystem extends Student
{
	StudentManagementSystem(String name,int id,int age,char grade)
	{
         super(name ,id,age,grade);
	}

    public static String add(String name,int id,int age,char grade)
	{
     List student =new ArrayList();
	 student.add(new Student(name,id,age,grade));
	 return "Studentn Successfully added";
	}
   public static  void retrieve(String name,int id,int age,char grade)
	{
       
    }
	public static  void update()
	{
     
	}
	public static String delete(String name,int id,int age,char grade)
	{
      return "";
	}
	public static void main(String [] args)
	{
		Scanner inp=new Scanner(System.in);

        int features=0;
		while (features!=8008)
		{
			System.out.println("WELCOME TO STUDENT MANAGEMENT SYSTEM");
		System.out.println("Please choose option ");
		System.out.println("1.Add new student i\n2.Delete Student information\n3.Update Student information\n4.Retrieve Student information\n5.EXIT\n");
		int menu = 0;
		menu=inp.nextInt();
		switch (menu)
		{
		case 1:
			System.out.print("enter your name: ");
		                     inp.next();
		       String name=inp.nextLine();
               System.out.print("enter your id: ");
			   int id=inp.nextInt();
               System.out.print("enter your age: ");
			   int age=inp.nextInt();
			   System.out.print("enter your grade: ");
			   char grade=inp.next().charAt(0);
			    System.out.println(add(name,id,age,grade));
		         break;
	    case 2:
			   System.out.println("2.Delete Student information");
		       break;
	    case 3:
			 System.out.println("3.Update Student information");
		      break;
		case 4:
			 System.out.println("4.Retrieve Student information");
		      break;
		case 5:
			 System.out.println("5.EXIT");
		      features=8008;
              break;
	     default:System.out.println("choose correct option");
		
		}

		}
		System.out.println("Hello World!");
	}		
}
